# Генератор цветовых палитр

Интерактивное веб-приложение на Vue.js для создания, управления и экспорта цветовых палитр.

## Возможности

### Практика 27 (Базовый функционал)
- ✅ Генерация гармоничных цветовых палитр
- ✅ Копирование цветов в буфер обмена
- ✅ Закрепление понравившихся цветов
- ✅ Выбор количества цветов (3, 5, 7)
- ✅ Переключение между форматами (HEX, RGB)
- ✅ Сохранение палитры в localStorage
- ✅ Превью палитры в mockup интерфейса
- ✅ Переключение светлого/тёмного фона

### Практика 28 (Продвинутый функционал)
- ✅ Генерация на основе базового цвета
- ✅ Различные типы палитр (аналогичная, монохромная, триада, комплементарная)
- ✅ Генерация по настроению (спокойные, энергичные, профессиональные и т.д.)
- ✅ Проверка контрастности по стандарту WCAG
- ✅ Управление библиотекой палитр
- ✅ Поиск и фильтрация палитр
- ✅ Экспорт в CSS variables, SCSS, Tailwind config
- ✅ Превью в UI компонентах
- ✅ Цветовой круг для выбора базового цвета

## Recommended IDE Setup

[VS Code](https://code.visualstudio.com/) + [Vue (Official)](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur).

## Recommended Browser Setup

- Chromium-based browsers (Chrome, Edge, Brave, etc.):
  - [Vue.js devtools](https://chromewebstore.google.com/detail/vuejs-devtools/nhdogjmejiglipccpnnnanhbledajbpd) 
  - [Turn on Custom Object Formatter in Chrome DevTools](http://bit.ly/object-formatters)
- Firefox:
  - [Vue.js devtools](https://addons.mozilla.org/en-US/firefox/addon/vue-js-devtools/)
  - [Turn on Custom Object Formatter in Firefox DevTools](https://fxdx.dev/firefox-devtools-custom-object-formatters/)

## Customize configuration

See [Vite Configuration Reference](https://vite.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```
